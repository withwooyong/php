<?
$SERVER_ALPHA = 0;
$SERVER_LIVE = 1;
$SERVER_MODE = $SERVER_ALPHA;

$APACHE_REWRITE_RULE = "thumbnails/";

$BASE_PATH  = "../thumbnails";

$DEFAULT_QUALITY_VALUE = 90;
$DEFAULT_TYPE_VALUE = "20";
$DEFAULT_COLOR_VALUE = "0";

$QUALITY_MIN = 0;
$QUALITY_MAX = 100;
$WIDTH_MIN = 0;
$WIDTH_MAX = 4000;
$HEIGHT_MIN = 0;
$HEIGHT_MAX = 4000;

//$BASE = "/svc/nsigs/thumbnail";

//$EXTRA_PATH = "/http";
//$INTRA_PATH = "/file";
//$HOSTNAME = array( "nsigs.hanafostv.com" );
//$DB_PATH = $BASE . "/database/thumbnail.db";
//$DB_NAME = $DB_PATH;

/*
$IMAGE_SOURCE_PATH = "/app/data/";
$SERVICE_LIST = array(
	"hoppin" => $IMAGE_SOURCE_PATH,
	"hoppin_cjenm" => "http://image.watchon.cjem.skcdn.com/",
	"hoppin_maxmovie" => "http://image.maxmovie.com/",
	"pickat" => "http://file.pickat.com/",
	"pickat_aws" => "http://img-pickatsg.s3.amazonaws.com/",
	"pickat_dev" => "http://file.pickat.kiwiple.net/",
	"tstore" => "http://www.tstore.co.kr/",
	"tstore_DEV" => "http://dev.tstore.co.kr/",
	"tstore_STG" => "http://stg.tstore.co.kr/",
	"img_qasac" => "http://qa-store.sungsu.skplanet.com/",
	"img_sac" => "http://store.sungsu.skplanet.com/",
	"dev_tshopping" => "http://dev-accgw.sktshopping.com/",
	"stage_tshopping" => "http://stage-accgw.sktshopping.com/",
	"tshopping" => "http://accgw.sktshopping.com/",
	"hd_tshopping" => "http://image.hyundaihmall.com/",
	"cj_tshopping" => "http://itemimage.cjmall.com/",
	"hn_tshopping" => "http://image.hnsmall.com/",
	"ns_tshopping" => "http://image.nsmall.com/",
	"lt_tshopping" => "http://image2.lotteimall.com/",
	"gs_tshopping" => "http://image.gsshop.com/",

	"tpass" => "http://tpass.skplanet.com/",
	"qatpass" => "http://stgtpass.skplanet.com:9900/",

	"ids_hoppin" => "http://211.188.203.64:8012/thumbnails/hoppin/"
);
*/

?>